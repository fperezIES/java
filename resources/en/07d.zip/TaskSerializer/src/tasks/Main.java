package tasks;

import java.util.*;
import java.io.*;

/**
 * Main program to manage a list of tasks
 */
public class Main
{
    private static final String FILENAME = "tasks.dat";

    private static List<Task> loadTasks()
    {
        List<Task> tasks = new ArrayList<>();
        try(ObjectInputStream in =
            new ObjectInputStream(new FileInputStream(FILENAME)))
        {
            tasks = (List<Task>)in.readObject();
        }
        catch (Exception e)
        {
            System.err.println("Error reading file: " + e.getMessage());
        }

        return tasks;
    }

    private static void saveTasks(List<Task> tasks)
    {
        try(ObjectOutputStream out =
            new ObjectOutputStream(new FileOutputStream(FILENAME)))
        {
            out.writeObject(tasks);
        }
        catch (Exception e)
        {
            System.err.println("Error writing file: " + e.getMessage());
        }
    }

    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        List<Task> tasks = loadTasks();
        String answer, description, date;

        System.out.println("Current task list:");
        for(Task t: tasks)
            System.out.println(t);

        System.out.println("Do you want to add a new task?(Y/N)");
        answer = sc.nextLine();

        if (answer.toUpperCase().equals("Y"))
        {
            System.out.println("Enter task description:");
            description = sc.nextLine();
            System.out.println("Enter task date:");
            date = sc.nextLine();
            tasks.add(new Task(description, date));
            saveTasks(tasks);
        }
    }
}
