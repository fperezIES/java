package tasks;

import java.io.Serializable;

/**
 * Class to store information about each task
 */
public class Task implements Serializable
{
    private String description;
    private String date;

    public Task(String description, String date)
    {
        this.description = description;
        this.date = date;
    }

    @Override
    public String toString()
    {
        return description + " (" + date + ")";
    }
}
