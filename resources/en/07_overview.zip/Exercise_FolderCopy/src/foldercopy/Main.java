package foldercopy;

import java.io.*;
import java.nio.file.*;

/**
 * This program copies the files of a source folder into a destination folder
 * ONLY files are copied (no folders allowed)
 */

public class Main
{
    /* Constants to refer to source and destination folders */
    public static final String SRC_FOLDER = "folder1";
    public static final String DST_FOLDER = "folder2";

    public static void copy()
    {
        try
        {
            if (!Files.exists(Paths.get(DST_FOLDER)))
            {
                Files.createDirectory(Paths.get(DST_FOLDER));
            }

            File[] srcFiles = Paths.get(SRC_FOLDER).toFile().listFiles();
            for(File f: srcFiles)
            {
                Files.copy(f.toPath(), Paths.get(DST_FOLDER + "/" + f.getName()));
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public static void removePrevious()
    {
        try
        {
            if (Files.exists(Paths.get(DST_FOLDER)))
            {
                File[] srcFiles = Paths.get(DST_FOLDER).toFile().listFiles();
                for(File f: srcFiles)
                {
                    Files.delete(f.toPath());
                }
                Files.delete(Paths.get(DST_FOLDER));
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {
        removePrevious();
        copy();
    }
}
