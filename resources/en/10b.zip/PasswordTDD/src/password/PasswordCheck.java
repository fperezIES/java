package password;

import java.util.regex.*;

public class PasswordCheck
{
    public static boolean check(String password)
    {
        boolean result = true;
        if (password == null || password.length() < 5 || password.length() > 10)
            result = false;
        else if (!Pattern.compile("\\d").matcher(password).find())
            result = false;
        else if (!Pattern.compile("[a-z]").matcher(password).find())
            result = false;
        else if (!Pattern.compile("[A-Z]").matcher(password).find())
            result = false;

        return result;
    }
}
