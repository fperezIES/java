package password;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PasswordCheckTest {

    @Test
    void check()
    {
        assertFalse(PasswordCheck.check(null));
        assertFalse(PasswordCheck.check("Ab1"));
        assertFalse(PasswordCheck.check("aaAbbBccC222"));
        assertFalse(PasswordCheck.check("abcde"));
        assertFalse(PasswordCheck.check("123ABC"));
        assertFalse(PasswordCheck.check("abc123"));
        assertTrue(PasswordCheck.check("ab12CD"));
    }
}