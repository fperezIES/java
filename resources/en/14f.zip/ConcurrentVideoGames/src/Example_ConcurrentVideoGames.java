
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * A class to store each video game data
 */
class VideoGame 
{
    String title;
    float price;
    
    public VideoGame(String title, float price)
    {
        this.title = title;
        this.price = price;
    }

    public String getTitle() 
    {
        return title;
    }

    public float getPrice() 
    {
        return price;
    }
        
    public synchronized void addPrice (float p)
    {
        price += p;
    }
}

/* Thread that will add/remove videogames to/from the list */
class AddSubstractThread extends Thread
{    
    /* List of video games */
    // With ArrayList: 
    // ArrayList<VideoGame> list;
    // With thread-safe collections:
    LinkedBlockingDeque<VideoGame> list;
    /* Flag to determin if this thread will add or remove games */
    boolean add;
    
    // With ArrayList: 
    // public AddSubstractThread(ArrayList<VideoGame> list, boolean add)
    // With thread-safe collections:
    public AddSubstractThread(LinkedBlockingDeque<VideoGame> list, boolean add)
    {
        this.list = list;
        this.add = add;
    }
    
    @Override
    public void run()
    {
        // Add/Substract 1 to/from the price

        // With ArrayList:
        /*
        for (int i = 0; i < list.size(); i++)
        {
            list.get(i).addPrice(add?1:-1);
            try { Thread.sleep(50); } catch (Exception e) {}
        }
        */
        // With thread-safe collections: 
        
        Iterator<VideoGame> iterator = list.iterator();
        while (iterator.hasNext())
        {
            VideoGame vg = iterator.next();
            vg.addPrice(add?1:-1);
            try { Thread.sleep(50); } catch (Exception e) {}
        }
    }    
}


/* Main class */
public class Example_ConcurrentVideoGames
{
    public static void main(String[] args) 
    {
        // Create a list of videogames
        
        // With ArrayList: 
        // ArrayList<VideoGame> list = new ArrayList<VideoGame>();
        // With thread-safe collections:
        LinkedBlockingDeque<VideoGame> list = new LinkedBlockingDeque<VideoGame>();
        
        for (int i = 1; i <= 100; i++)
            list.add(new VideoGame("Videogame " + i, 5));

        // Create and launch a thread to add games and a thread to remove them
        AddSubstractThread adder = new AddSubstractThread(list, true);
        AddSubstractThread substracter = new AddSubstractThread(list, false);
        adder.start();
        substracter.start();
        
        do
        {
            try { Thread.sleep(100); } catch (Exception e) {}
        } while (adder.isAlive() || substracter.isAlive());
        
        float total = 0;
        // With ArrayList:
        /*
        for (int i = 0; i < list.size(); i++)
            total += list.get(i).getPrice();
        */
        // With thread-safe collections:
        Iterator<VideoGame> iterator = list.iterator();
        while (iterator.hasNext())
        {
            VideoGame vg = iterator.next();
            total += vg.getPrice();
        }

        System.out.println("Task finished. Total price = " + total);
    }
    
}
