

import java.util.concurrent.atomic.AtomicInteger;

/* Shared object */
class Counter
{
   AtomicInteger value;

   public Counter(int value)
   {
      this.value = new AtomicInteger(value);
   }

   // What if we remove the "synchronized" keyword in these two methods?
   
   public void increment()
   {
      value.incrementAndGet();
   }

   public void decrement()
   {
      value.decrementAndGet();
   }

   public int getValue()
   {
      return value.get();
   }
}

/* Thread that increments the counter */
class ThreadInc extends Thread
{
   Counter c;

   public ThreadInc(Counter c)
   {
      this.c = c;
   }

   @Override
   public void run()
   {
      for (int i = 0; i < 100; i++)
      {
         c.increment();
         try
         {
            Thread.sleep(100);
         } catch (InterruptedException e) {}
      }
      System.out.println("Finishing increment. Final value = " + c.getValue());
   }
}

/* Thread that decrements the counter */
class ThreadDec extends Thread
{
   Counter c;

   public ThreadDec(Counter c)
   {
      this.c = c;
   }

   @Override
   public void run()
   {
      for (int i = 0; i < 100; i++)
      {
         c.decrement();
         try
         {
            Thread.sleep(100);
         } catch (InterruptedException e) {}
      }
      System.out.println("Finishing decrement. Final value = " + c.getValue());
   }
}

/* Main class */
class Exercise_AtomicCounter
{
    public static void main(String[] args) 
    {
        Counter c = new Counter(100);
        ThreadInc ti = new ThreadInc(c);
        ThreadDec td = new ThreadDec(c);
        ti.start();
        td.start();
    }
    
}
