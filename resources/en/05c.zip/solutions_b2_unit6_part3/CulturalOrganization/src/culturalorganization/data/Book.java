package culturalorganization.data;

/**
 * A subtype of cultural object
 */

public class Book extends CulturalObject
{
    private int numberOfPages;

    public Book(int numberOfPages, int id, String title, String author) {
        super(id, title, author);
        this.numberOfPages = numberOfPages;
    }

    public int getNumberOfPages() {
        return numberOfPages;
    }

    public void setNumberOfPages(int numberOfPages) {
        this.numberOfPages = numberOfPages;
    }

    @Override
    public String toString() {
        return super.toString() + " Book{" + "numberOfPages=" + numberOfPages + '}';
    }
}
