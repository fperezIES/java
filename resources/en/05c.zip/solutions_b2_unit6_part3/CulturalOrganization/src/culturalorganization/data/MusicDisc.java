package culturalorganization.data;

/**
 * A subtype of cultural object
 */

public class MusicDisc extends CulturalObject
{
    private String recordCompany;

    public MusicDisc(String recordCompany, int id, String title, String author) {
        super(id, title, author);
        this.recordCompany = recordCompany;
    }

    public String getRecordCompany() {
        return recordCompany;
    }

    public void setRecordCompany(String recordCompany) {
        this.recordCompany = recordCompany;
    }

    @Override
    public String toString() {
        return super.toString() + " MusicDisc{" + "recordCompany=" + recordCompany + '}';
    } 
}
