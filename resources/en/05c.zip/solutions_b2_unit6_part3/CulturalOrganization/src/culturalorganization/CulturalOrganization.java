package culturalorganization;

import culturalorganization.data.Book;
import culturalorganization.data.CulturalObject;
import culturalorganization.data.Loan;
import culturalorganization.data.MusicDisc;
import culturalorganization.data.User;

/**
 * Main class that creates som cultural objects and a user that gets them in loan
 */

public class CulturalOrganization 
{
    public static void main(String[] args) 
    {
        // We create a pre-defined array of cultural objects, which will be our catalog
        CulturalObject[] objects = new CulturalObject[3];
        objects[0] = new Book(200, 1, "Ender's game", "Orson Scott Card");
        objects[1] = new MusicDisc("AAA", 2, "Crossroad", "Bon Jovi");
        objects[2] = new MusicDisc("BBB", 2, "Zooropa", "U2");

        // User u loans some objects
        User u = new User("1111111A", "Nacho");
        Loan l = new Loan("07/03/2020", "21/03/2020", objects[0]);
        Loan l2 = new Loan("10/03/2020", "24/03/2020", objects[1]);
        u.addLoan(l);   // This way, loan is associated to user and vice versa
        u.addLoan(l2);

        System.out.println(u);
        System.out.println(l2.getUser());
    }
    
}
