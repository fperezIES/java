package blog.data;

/**
 * This is a subtype of User class for users who can
 * comment posts
 */

public class Visitor extends User{

    // In this case, the relationship between visitors and comments
    // is stored in Comment class, instead of Visitor class, as we
    // did for Editors and Posts

    public Visitor(String login, String password) {
        super(login, password);
    }
    
    public void commentPost(Post post, Comment comment)
    {
        // Set the visitor who added the comment
        comment.setVisitor(this);
        // Add the comment to the post
        post.addComment(comment);
        
    }

    
}
