package blog.data;

/**
 * This class stores the features of every comment of every post,
 * including the Visitor who created the comment
 */

public class Comment {

    private String text;
    private String date;
    private Visitor visitor;
    
    public Comment(String text, String date, Visitor visitor)
    {
        this.text = text;
        this.date = date;
        this.visitor = visitor;
    }

    public Visitor getVisitor() {
        return visitor;
    }

    public void setVisitor(Visitor visitor) {
        this.visitor = visitor;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
