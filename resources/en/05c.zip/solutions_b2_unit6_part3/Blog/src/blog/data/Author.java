package blog.data;

/**
 * Author class is a subtype of Editor class for users who can
 * publish posts, but they must be supervised by an Editor.
 */

public class Author extends Editor {
    
    protected Editor supervisor;
    
    public Author(String login, String password, Editor supervisor) 
    {
        super(login, password);
        this.supervisor = supervisor;
    }

    public Editor getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Editor supervisor) {
        this.supervisor = supervisor;
    }

    @Override
    public String toString() {
        return super.toString() + " Author{" + "supervisor=" + supervisor + '}';
    }
}
