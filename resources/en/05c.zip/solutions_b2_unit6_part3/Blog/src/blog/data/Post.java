package blog.data;

/**
 * This class stores information about every post published. We can add
 * some information about a post, such as its title, content or date. Besides,
 * every post has a list (array) of comments.
 */

public class Post {

    private String title;
    private String content;
    private String date;
    private  Comment[] comments;
    // Private counter to store how many comments are actually added to the array
    private int numComments;

    private static final int MAX_COMMENTS = 100;
    
    public Post(String title, String content, String date)
    {
        this.title = title;
        this.content = content;
        this.date = date;

        // We initialize the comments array with space for up to MAX_COMMENTS comments
        comments = new Comment[MAX_COMMENTS];
        // Initially, there are no comments in the array
        numComments = 0;
    }

    public Comment[] getComments() {
        return comments;
    }

    public int getNumComments() {
        return numComments;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    /**
     * This method adds a new comment to the array
     */
    public void addComment(Comment comment) {
        if (numComments < MAX_COMMENTS) {
            comments[numComments] = comment;
            numComments++;
        }
    }       
}
