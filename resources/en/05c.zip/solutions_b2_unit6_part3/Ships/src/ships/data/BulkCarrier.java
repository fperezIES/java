package ships.data;

public class BulkCarrier extends Ship
{
    private int loadHatches;

    public BulkCarrier(int loadHatches, String name, int anchors, String material, int length) {
        super(name, anchors, material, length);
        this.loadHatches = loadHatches;
    }

    public int getLoadHatches() {
        return loadHatches;
    }

    public void setLoadHatches(int loadHatches) {
        this.loadHatches = loadHatches;
    }

    @Override
    public String toString() {
        return super.toString() + " BulkCarrier{" + "loadHatches=" + loadHatches + '}';
    }
}
