package videogame.character;

public class Farmer extends Citizen {
	
	protected String movementType;
	protected String job;
	protected int workLevel;
	
	public Farmer(int age, int height, String genre, int lifeLevel, String tool, String movementType, String job,
			int workLevel) {
		super(age, height, genre, lifeLevel, tool);
		this.movementType = movementType;
		this.job = job;
		this.workLevel = workLevel;
	}
	
	public String getMovementType() {
		return movementType;
	}
	
	public void setMovementType(String movementType) {
		this.movementType = movementType;
	}
	
	public String getJob() {
		return job;
	}
	
	public void setJob(String job) {
		this.job = job;
	}
	
	public int getWorkLevel() {
		return workLevel;
	}
	
	public void setWorkLevel(int workLevel) {
		this.workLevel = workLevel;
	}
	
	@Override
	public String toString() {
		return super.toString() + " Farmer [movementType=" + movementType + ", job=" + job + ", workLevel=" + workLevel + "]";
	}
	
	
}
