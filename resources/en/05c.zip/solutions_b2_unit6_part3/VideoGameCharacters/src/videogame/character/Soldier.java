package videogame.character;

public class Soldier extends Character {

	protected String weapon;

	public Soldier(int age, int height, String genre, int lifeLevel, String weapon) {
		super(age, height, genre, lifeLevel);
		this.weapon = weapon;
	}

	public String getWeapon() {
		return weapon;
	}

	public void setWeapon(String weapon) {
		this.weapon = weapon;
	}

	@Override
	public String toString() {
		return super.toString() + " Soldier [weapon=" + weapon + "]";
	}
	
	
}
