package videogame.character;

public class Citizen extends Character {

	protected String tool;

	public Citizen(int age, int height, String genre, int lifeLevel, String tool) {
		super(age, height, genre, lifeLevel);
		this.tool = tool;
	}

	public String getTool() {
		return tool;
	}

	public void setTool(String tool) {
		this.tool = tool;
	}

	@Override
	public String toString() {
		return super.toString() + " Citizen [tool=" + tool + "]";
	}
	
	
}
