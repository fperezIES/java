package videogame.character;

public class Knight extends Soldier{
	
	protected String movementType;
	protected int damage;
	protected int horseLiveLevel;
	
	public Knight(int age, int height, String genre, int lifeLevel, String weapon, String movementType, int damage,
			int horseLiveLevel) {
		super(age, height, genre, lifeLevel, weapon);
		this.movementType = movementType;
		this.damage = damage;
		this.horseLiveLevel = horseLiveLevel;
	}

	public String getMovementType() {
		return movementType;
	}

	public void setMovementType(String movementType) {
		this.movementType = movementType;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public int getHorseLiveLevel() {
		return horseLiveLevel;
	}

	public void setHorseLiveLevel(int horseLiveLevel) {
		this.horseLiveLevel = horseLiveLevel;
	}

	@Override
	public String toString() {
		return super.toString() + " Knight [movementType=" + movementType + ", damage=" + damage + ", horseLiveLevel=" + horseLiveLevel
				+ "]";
	}
		
}
