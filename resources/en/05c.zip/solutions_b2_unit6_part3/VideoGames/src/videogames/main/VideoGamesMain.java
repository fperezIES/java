package videogames.main;

import java.util.Scanner;
import videogames.data.PCVideoGame;
import videogames.data.VideoGame;
import videogames.data.Company;

public class VideoGamesMain
{
    public static final int MAX_VIDEOGAMES = 5;
    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        VideoGame[] games = new VideoGame[MAX_VIDEOGAMES];
        int minPos = 0, maxPos = 0, chosenCompany, chosenType;
        
        // Pre-defined array of companies
        
        Company[] companies = new Company[3];
        companies[0] = new Company("Capcom", 1987);
        companies[1] = new Company("UbiSoft", 1998);
        companies[2] = new Company("EA Sports", 1990);
        
        for(int i = 0; i < MAX_VIDEOGAMES; i++)
        {
			System.out.println("Choose the game type (1. VideoGame, 2. PC VideoGame)");
			chosenType = sc.nextInt();
			sc.nextLine();
			
			switch(chosenType)
			{
				case 2: 
					games[i] = new PCVideoGame();
					break;
				default: 
					games[i] = new VideoGame();
					break;
			}
            
            System.out.println("Enter title for videogame " + (i+1) + ":");
            games[i].setTitle(sc.nextLine());
            
            System.out.println("Enter genre for videogame " + (i+1) + ":");
            games[i].setGenre(sc.nextLine());

            System.out.println("Enter price for videogame " + (i+1) + ":");
            games[i].setPrice(sc.nextFloat());
            
            // Add company to the video game
            
            for (int j = 0; j < companies.length; j++)
            {
				System.out.println((j+1) + ". " + companies[j].getName());
			}
			System.out.println("Choose a company from the list (1 - " + 
				companies.length + "):");
            chosenCompany = sc.nextInt();
            sc.nextLine();
            games[i].setCompany(companies[chosenCompany - 1]);
            
            if (chosenType == 2)
            {
				System.out.println("Choose the minimum RAM:");
				((PCVideoGame)games[i]).setMinimumRAM(sc.nextInt());
				System.out.println("Choose the minimum HD:");
				((PCVideoGame)games[i]).setMinimumHD(sc.nextInt());
			}
        } 
        
        // Cheapest and most expensive video game
        
        for (int i = 1; i < MAX_VIDEOGAMES; i++)
        {
            if (games[i].getPrice() > games[maxPos].getPrice())
            {
                maxPos = i;
            }
            
            if (games[i].getPrice() < games[minPos].getPrice())
            {
                minPos = i;
            }
        }
        
        System.out.println("Cheapest videogame: " + games[minPos].getTitle());
        System.out.println("Most expensive videogame: " + games[maxPos].getTitle());
        
        // Show static counter
        System.out.println(VideoGame.getCounter() + " video games have been created so far.");
    }	
}
