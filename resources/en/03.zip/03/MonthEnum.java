/**
 * Program that defines an enum with the month names and then uses it to
 * check the number of days of a month entered by the user
 */

import java.util.Scanner;

enum month {
    JANUARY, FEBRUARY, MARCH, APRIL, MAY, JUNE, JULY, AUGUST, SEPTEMBER, OCTOBER, NOVEMBER, DECEMBER
}

public class MonthEnum {
    public static void main(String[] args) {
        int[] monthDays = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        month userMonth;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter month (JANUARY - DECEMBER):");
        userMonth = month.valueOf(sc.nextLine());

        System.out.println("This month has " + monthDays[userMonth.ordinal()] + " days");
    }
}
