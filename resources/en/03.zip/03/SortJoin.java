/**
 * Program that asks the user to enter names separated by whitespaces,
 * then it splits them, sort them alphabetically and show them
 * separated by commas
 */

import java.util.Scanner;

public class SortJoin {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // 1. Read names
        System.out.println("Enter the names separated by whitespaces:");
        String input = sc.nextLine();

        // 2. Split names
        String[] names = input.split(" ");

        // 3. Sort names
        for (int i = 0; i < names.length - 1; i++) {
            for (int j = i + 1; j < names.length; j++) {
                if (names[i].compareTo(names[j]) > 0) {
                    String aux = names[i];
                    names[i] = names[j];
                    names[j] = aux;
                }
            }
        }

        // 4. Show result
        for (int i = 0; i < names.length; i++) {
            System.out.print(names[i]);
            if (i < names.length - 1) {
                System.out.print(",");
            }
        }

        // Alternatively, we can sort the names with
        // Arrays.sort(names);
        // And then join them with commas with:
        // String output = String.join(",", names);
    }
}
