module My3Counters {

    requires javafx.controls;
    requires javafx.fxml;

    opens my3counters;
}