/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my3counters;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


/**
 *
 * @author arturo
 */
public class My3CountersController {

    @FXML
    private Button button1;
    @FXML
    private Label label1;
    @FXML
    private Button button2;
    @FXML
    private Label label2;
    @FXML
    private Button button3;
    @FXML
    private Label label3;

    private Runnable createCounter(int from, int to, Label label) {
        return () -> {
            int current = from;
            int endNum = (from < to)? to + 1 : to - 1;
            do {
                try {
                    Thread.sleep(1000);
                    final int printCurrent = current;
                    Platform.runLater(() -> label.setText("Counting... " + printCurrent));
                } catch (InterruptedException ex) {}
                current += (from < to)? 1 : -1;

            } while (current != endNum);
        };
    }

    public void initialize() {
    }

    @FXML
    private void count1_10(ActionEvent event) {
        button1.setDisable(true);
        Thread t = new Thread(createCounter(1, 10, label1));
        t.start();
    }

    @FXML
    private void count1_5(ActionEvent event) {
        button2.setDisable(true);
        Thread t = new Thread(createCounter(1, 5, label2));
        t.start();
    }

    @FXML
    private void count10_1(ActionEvent event) {
        button3.setDisable(true);
        Thread t = new Thread(createCounter(10, 1, label3));
        t.start();
    }

}
