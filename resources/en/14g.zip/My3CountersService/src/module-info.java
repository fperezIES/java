module My3CountersService {

    requires javafx.fxml;
    requires javafx.controls;

    opens my3counters;
}