/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my3counters;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class My3CountersController {

    @FXML
    private Button button1;
    @FXML
    private Label label1;
    @FXML
    private Button button2;
    @FXML
    private Label label2;
    @FXML
    private Button button3;
    @FXML
    private Label label3;
    
    private Service<Void> service1_10;
    private Service<Void> service1_5;
    private Service<Void> service10_1;

    public Service<Void> createCounterService(int from, int to) {
        return new Service<Void>() {
            @Override
            protected Task<Void> createTask() {
                return new Task<Void>() {
                    @Override
                    protected Void call() throws Exception {
                        int current = from;
                        int endNum = (from < to) ? to + 1 : to - 1;
                        do {
                            try {
                                Thread.sleep(1000);
                                updateMessage("Counting... " + current);
                            } catch (Exception ex) {
                            }
                            current += (from < to) ? 1 : -1;

                        } while (current != endNum);
                        
                        return null;
                    }
                };
            }
        };
    }

    public void initialize() {
        service1_10 = createCounterService(1, 10);
        service1_5 = createCounterService(1, 5);
        service10_1 = createCounterService(10, 1);
        
        label1.textProperty().bind(service1_10.messageProperty());
        label2.textProperty().bind(service1_5.messageProperty());
        label3.textProperty().bind(service10_1.messageProperty());
        
        service1_10.setOnSucceeded(e -> {
            button1.setDisable(false);
            service1_10.reset();
        });
        
        service1_5.setOnSucceeded(e -> {
            button2.setDisable(false);
            service1_5.reset();
        });
        
        service10_1.setOnSucceeded(e -> {
            button3.setDisable(false);
            service10_1.reset();
        });
    }

    @FXML
    private void count1_10(ActionEvent event) {
        button1.setDisable(true);
        service1_10.start();
    }

    @FXML
    private void count1_5(ActionEvent event) {
        button2.setDisable(true);
        service1_5.start();
    }

    @FXML
    private void count10_1(ActionEvent event) {
        button3.setDisable(true);
        service10_1.start();
    }

}
