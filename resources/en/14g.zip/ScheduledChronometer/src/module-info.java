module ScheduledChronometer {

    requires javafx.controls;
    requires javafx.fxml;
    opens scheduledchronometer;
}