

import java.util.concurrent.locks.*;

public class BankAccount 
{
    int balance;
    Lock lock;
    
    public BankAccount(int balance)
    {
        this.balance = balance;
        this.lock = new ReentrantLock();
    }
    
    public void addMoney(int money)
    {
        lock.lock();
        balance += money;
        System.out.println("Money added. Current Balance: " + balance);
        lock.unlock();
    }
    
    public void takeOutMoney(int money)
    {
        lock.lock();
        balance -= money;
        System.out.println("Money taken out. Current Balance: " + balance);
        lock.unlock();
    }
    
    public int getBalance()
    {
        return balance;
    }
}
