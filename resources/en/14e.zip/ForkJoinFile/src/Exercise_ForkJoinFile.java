
import java.io.*;
import java.util.concurrent.*;
import java.util.ArrayList;

/* Task that will check the lines */
class ReplaceTask extends RecursiveAction
{
    // Maximum number of lines to check
    static final int MAX_LINES = 10;
    
    // Whole set of lines
    String[] lines;
    // First position to start checking
    int first;
    // Last position to end checking
    int last;
    
    public ReplaceTask(String[] lines, int first, int last)
    {
        this.lines = lines;
        this.first = first;
        this.last = last;
    }
    
    @Override
    protected void compute()
    {
        if (last - first <= MAX_LINES)
        {
            replace();
        } else {
            int total = (last - 1) / MAX_LINES + 1;
            ArrayList<ReplaceTask> subtasks = new ArrayList<>();
            for (int i = 0; i < total; i++)
            {
                ReplaceTask rt = new ReplaceTask(lines, i*10, i*10 + 10);
                subtasks.add(rt);
            }
            invokeAll(subtasks);
        }
    }
    
    private void replace()
    {
        for (int i = first; i < last; i++)
        {
            if (i < lines.length)
                lines[i] = lines[i].replaceAll("java", "Java");
            else
                break;
        }
    }
}

/* Main class */
public class Exercise_ForkJoinFile
{
    public static void main(String[] args) 
    {
        ArrayList<String>lines = new ArrayList<>();
        String[] lineArray = null;
        BufferedReader br = null;
        PrintWriter pw = null;
        
        // Read input file and store lines 
        try
        {
            br = new BufferedReader(new FileReader("test.txt"));
            String line = "";
            while ((line = br.readLine()) != null)
            {
                lines.add(line);
            }
        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
        } finally {
            try { br.close(); } catch (Exception e) {}
        }
        
        // Create an array with the lines read
        lineArray = new String[lines.size()];
        lineArray = lines.toArray(lineArray);
        
        System.out.println("Processing " + lineArray.length + " lines.");
        
        // Create the pool and the main task
        ReplaceTask rt = new ReplaceTask(lineArray, 0, lineArray.length);
        ForkJoinPool pool = new ForkJoinPool();
        pool.execute(rt);
       
        do
        {
            try { Thread.sleep(100); } catch (Exception e) {}
        } while (!rt.isDone());
        
        // Write the modified lines
        try
        {
            pw = new PrintWriter("test_replaced.txt");
            for (int i = 0; i < lineArray.length; i++)
            {
                pw.println(lineArray[i]);
            }
        } catch (Exception e) {
        } finally {
            pw.close();
        }

        pool.shutdown();
        
    }
    
}
