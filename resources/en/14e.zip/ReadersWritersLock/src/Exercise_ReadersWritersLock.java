

import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/* Data to be read/written */

class MyData
{
   int value;
   ReentrantReadWriteLock lock;

   public MyData(int value)
   {
      this.value = value;
      lock = new ReentrantReadWriteLock();
   }

   public int getValue()
   {
      lock.readLock().lock();
      try { Thread.sleep(2000); } catch (Exception e) {}
      System.out.println("Thread #" + Thread.currentThread().getId() + " reads value " + value);
      int v = value;
      lock.readLock().unlock();
      return v;
   }

   public void setValue(int value)
   {
      lock.writeLock().lock();
      try { Thread.sleep(2000); } catch (Exception e) {}
      System.out.println("Thread #" + Thread.currentThread().getId() + " sets value to " + (this.value + value));
      this.value += value;
      lock.writeLock().unlock();
   }
}

/* A thread to read the shared data */
class ReadingThread extends Thread
{
   MyData sharedData;
   Random r;

   public ReadingThread(MyData sharedData, Random r)
   {
      this.sharedData = sharedData;
      this.r = r;
   }

   @Override
   public void run()
   {
      int seconds = r.nextInt(10) + 1;
      try { TimeUnit.SECONDS.sleep(seconds); } catch (Exception e) {}
      int value = sharedData.getValue();
   }
}

/* A thread to read the shared data */
class WritingThread extends Thread
{
   MyData sharedData;
   Random r;

   public WritingThread(MyData sharedData, Random r)
   {
      this.r = r;
      this.sharedData = sharedData;
   }

   @Override
   public void run()
   {
      int seconds = r.nextInt(10) + 1;
      try { TimeUnit.SECONDS.sleep(seconds); } catch (Exception e) {}
      sharedData.setValue(10);
   }
}

/* Main class */
public class Exercise_ReadersWritersLock
{
    public static void main(String[] args) 
    {
        Random r = new Random (System.currentTimeMillis());
        MyData mds = new MyData(10);
        ReadingThread[] threadsR = new ReadingThread[10];
        WritingThread[] threadsW = new WritingThread[2];

        for (int i = 0; i < threadsW.length; i++)
        {
            threadsW[i] = new WritingThread(mds, r);
        }

        for (int i = 0; i < threadsR.length; i++)
        {
            threadsR[i] = new ReadingThread(mds, r);
        }

        for (int i = 0; i < threadsW.length; i++)
        {
            threadsW[i].start();
        }
        for (int i = 0; i < threadsR.length; i++)
        {
            threadsR[i].start();
        }
        
    }
    
}
