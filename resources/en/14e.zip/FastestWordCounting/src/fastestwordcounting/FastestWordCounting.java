/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fastestwordcounting;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

public class FastestWordCounting {

    public static CompletableFuture<Integer> wordCounter(String word, String file) {
        return CompletableFuture.supplyAsync(() -> {
            try (Stream<String> stream = Files.lines(Paths.get(file))) {
                return stream
                        .mapToInt(line -> {
                            int count = 0;
                            int index = -1;
                            while ((index = line.indexOf(word, index + 1)) != -1) {
                                count++;
                            }
                            return count;
                        })
                        .sum();
            } catch (IOException ex) {
                System.err.println("Error reading " + file);
            }
            return 0;
        });
    }

    public static void main(String[] args) {
        String word = "alcohol";
        CompletableFuture<Object> anyTask = CompletableFuture.anyOf(
            wordCounter(word, "text1.txt"),
            wordCounter(word, "text2.txt"),
            wordCounter(word, "text3.txt")
        );

        anyTask.thenAccept((val) -> System.out.println("Found '" + word + "' " + val + " times"));

        while (!anyTask.isDone()) { // Wait for the tasks to end
            try {
                TimeUnit.MILLISECONDS.sleep(500);
            } catch (InterruptedException ex) {}
        }

    }

}
