/**
 * Program to check the final result of a variable
 */

public class CheckResult {
    public static void main(String[] args) {
        int result = 4;
        result += 3;
        result *= 2;
        result--;
        result %= 4;

        System.out.println(result);
    }
}
