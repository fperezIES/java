/**
 * Exercise that asks the user to enter a day, month and year of birth
 * and then it prints the date with the format d/m/y
 */

import java.util.Scanner;

public class FormattedDate {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter you day of birth");
        int day = sc.nextInt();
        System.out.println("Enter you month of birth");
        int month = sc.nextInt();
        System.out.println("Enter you year of birth");
        int year = sc.nextInt();

        System.out.println(day + "/" + month + "/" + year);

        sc.close();
    }
}
