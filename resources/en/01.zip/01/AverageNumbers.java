/**
 * Example of clean code
 */

// Program that asks the user three numbers and calculates the average

import java.util.Scanner;

public class AverageNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce three numbers:");
        int number1 = sc.nextInt();
        int number2 = sc.nextInt();
        int number3 = sc.nextInt();
        /* We could have used a float number instead, 
            but we decided to keep this program as 
            simple as we could */
        int average = (number1 + number2 + number3) / 3;
        System.out.println("The average is " + average);
    }
}

// Original source file
//
//import java.util.Scanner;
//
//public class AverageNumbers {
//    public static void main(String[] args) {
//        // Variables to store the three numbers and the average
//        int n1, n2, n3;
//        int Result;
//        Scanner sc = new Scanner(System.in);
//
//        // We ask the user to enter three numbers
//        System.out.println("Introduce three numbers:");
//        n1 = sc.nextInt();
//        n2 = sc.nextInt();
//        n3 = sc.nextInt();
//        // The result is the average of these numbers
//        /* We could have used a float number instead,
//            but we decided to keep this program as
//            simple as we could */
//        Result = (n1 + n2 + n3) / 3;
//        System.out.println("The average is " + Result);
//    }
//}

