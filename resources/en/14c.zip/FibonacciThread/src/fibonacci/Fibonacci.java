package fibonacci;

public class Fibonacci {

    public static void main(String[] args)
    {
        Thread t = new FibonacciThread(20);
        t.start();
    }

}
