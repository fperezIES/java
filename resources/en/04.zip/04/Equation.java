/*
 * This program tries to solve a 2nd degree equation given the values of
 * a, b and c (equation coefficients)
 */

import java.util.Scanner;

public class Equation {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter value for a:");
        int a = sc.nextInt();
        System.out.println("Enter value for b:");
        int b = sc.nextInt();
        System.out.println("Enter value for c:");
        int c = sc.nextInt();

        // If a is 0 it's not a 2nd degree equation
        if (a != 0) {
            // We check if square root can be calculated
            double discriminant = b * b - 4 * a * c;
            if (discriminant >= 0) {
                // Equation has solutions
                double x1 = (-b + Math.sqrt(discriminant)) / (2 * a);
                double x2 = (-b - Math.sqrt(discriminant)) / (2 * a);

                System.out.println("x1 = " + x1);
                System.out.println("x2 = " + x2);
            } else {
                System.out.println("Equation has no real solutions");
            }
        } else {
            System.out.println("Not valid 2nd degree equation");
        }
    }
}
