/*
 * This program generates a random number between 1 and 50 and makes the
 * user try to guess it (with 5 attempts)
 */

import java.util.Scanner;

public class NumberGuess {
    public static void main(String[] args) {
        int secretNumber = (int) (Math.random() * 50) + 1;
        int attempts = 0, userNumber = 0;
        Scanner sc = new Scanner(System.in);

        while (attempts < 5 && userNumber != secretNumber) {
            System.out.println("Enter a number:");
            userNumber = sc.nextInt();

            if (secretNumber > userNumber) {
                System.out.println("Secret number is higher");
            } else if (secretNumber < userNumber) {
                System.out.println("Secret number is lower");
            }
            attempts++;
        }

        if (userNumber == secretNumber) {
            System.out.println("Congratulations! You win!");
        } else {
            System.out.println("You exceeded your number of attempts");
            System.out.println("Secret number was " + secretNumber);
        }
    }
}
