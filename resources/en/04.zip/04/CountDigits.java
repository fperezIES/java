/*
 * This program calculates recursively the number of digits of a given number
 */

public class CountDigits {
    public static int countDigits(int n) {

        if (n < 10) {
            // Base case: number has one digit
            return 1;
        } else {
            // Recursive case: we divide by 10 and increase 1 digit
            return 1 + countDigits(n / 10);
        }
    }

    public static void main(String[] args) {
        System.out.println(countDigits(1252));
    }
}
