/*
 * This program calculates recursively if a text is palindrome or not
 */
  
public class PalindromeRecursive
{
    public static boolean isPalindrome(String text)
    {

        if (text.length() <= 1) {
            // Base case: text is empty or has 1 character
            return true;
        }
        else {
            // Recursive case: we compare edges and go on with the rest of string
            return text.charAt(0) == text.charAt(text.length() - 1) &&
                    isPalindrome(text.substring(1, text.length() - 1));
        }
    }
    
    public static void main(String[] args)
    {
        System.out.println(isPalindrome("hannah"));
        System.out.println(isPalindrome("toohottohoot"));
        System.out.println(isPalindrome("javaisthebestlanguage"));
    }
}
