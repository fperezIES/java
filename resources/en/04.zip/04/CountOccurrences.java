public class CountOccurrences {
    public static boolean countString(String a, String b, int n) {
        int pos;
        int times = 0;

        do {
            pos = a.indexOf(b);
            if (pos >= 0) {
                times++;
                a = a.substring(pos + b.length());
            }
        }
        while (times < n && pos >= 0);

        return times == n;
    }

    public static void main(String[] args) {
        System.out.println(countString("This string is just a sample string", "string", 2));
    }
}
