module GrowingButton {
    requires javafx.controls;
    requires javafx.fxml;

    opens growingbutton;
}