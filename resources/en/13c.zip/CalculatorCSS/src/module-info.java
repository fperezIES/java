module CalculatorEventCSS {
    requires javafx.controls;
    requires javafx.fxml;

    opens calculator;
}