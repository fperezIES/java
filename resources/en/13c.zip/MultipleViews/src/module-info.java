module multipleViews {
    requires javafx.fxml;
    requires javafx.controls;

    opens multipleviews;

}