module Temperatures {

    requires javafx.fxml;
    requires javafx.controls;

    opens temperatures;
}