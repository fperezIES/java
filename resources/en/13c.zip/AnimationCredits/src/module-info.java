module AnimationCredits {
    requires javafx.fxml;
    requires javafx.controls;

    opens animationcredits;
}