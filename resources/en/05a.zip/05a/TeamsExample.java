/*
 * In this exercise, we define a Team class with some attributes,
 * constructor and getters/setters, and then in the main program we
 * create a Team object to show its information
 */

import java.util.Scanner;

/*
 * Team class
 */
class Team {
    private String name;
    private int foundationYear;

    public Team(String name, int foundationYear) {
        this.name = name;
        this.foundationYear = foundationYear;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFoundationYear() {
        return foundationYear;
    }

    public void setFoundationYear(int foundationYear) {
        this.foundationYear = foundationYear;
    }
}

/*
 * Main class
 */
public class TeamsExample {
    public static void main(String[] args) {
        Team team = new Team("Java F.C.", 1995);

        // This causes an error because name is private
        // System.out.println(team.name);

        // This is the correct way of getting team's info
        System.out.println(team.getName());
        System.out.println(team.getFoundationYear());
    }
}


