/*
 * In this exercise, we define a VideoGame class with some attributes,
 * constructor and getters/setters, and then in the main program we
 * create a VideoGame array, ask the user to fill the data and then
 * look for the cheapest and most expensive video game in the array
 */

import java.util.Scanner;

/*
 * VideoGame class
 */
class VideoGame {
    private String title;
    private String genre;
    private float price;

    public VideoGame() {
        title = "";
        genre = "";
        price = 0;
    }

    public VideoGame(String title, String genre, float price) {
        this.title = title;
        this.genre = genre;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}

/*
 * Main class
 */
public class VideoGameList {
    public static final int MAX_VIDEOGAMES = 5;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        VideoGame[] games = new VideoGame[MAX_VIDEOGAMES];
        
        /*
         * One way of getting video game data from the user:
         * Defining individual variables for each attribute and
         * then calling the constructor
         * 
        for(int i = 0; i < MAX_VIDEOGAMES; i++)
        {
            String title, genre;
            float price;
            
            System.out.println("Enter title for videogame " + (i+1) + ":");
            title = sc.nextLine();
            
            System.out.println("Enter genre for videogame " + (i+1) + ":");
            genre = sc.nextLine();

            System.out.println("Enter price for videogame " + (i+1) + ":");
            price = sc.nextFloat();
            
            games[i] = new VideoGame(title, genre, price);            
        }
        */

        /*
         * Another way: Calling an empty constructor and filling the
         * information of the object by calling the setters
         */
        for (int i = 0; i < MAX_VIDEOGAMES; i++) {
            games[i] = new VideoGame();

            System.out.println("Enter title for videogame " + (i + 1) + ":");
            games[i].setTitle(sc.nextLine());

            System.out.println("Enter genre for videogame " + (i + 1) + ":");
            games[i].setGenre(sc.nextLine());

            System.out.println("Enter price for videogame " + (i + 1) + ":");
            games[i].setPrice(sc.nextFloat());
            sc.nextLine();
        }


        /*
         * Get cheapest and most expensive video game
         */

        int minPos = 0, maxPos = 0;

        for (int i = 1; i < MAX_VIDEOGAMES; i++) {
            if (games[i].getPrice() > games[maxPos].getPrice()) {
                maxPos = i;
            }

            if (games[i].getPrice() < games[minPos].getPrice()) {
                minPos = i;
            }
        }

        System.out.println("Cheapest videogame: " + games[minPos].getTitle());
        System.out.println("Most expensive videogame: " + games[maxPos].getTitle());

    }
}


