/**
 * Program that asks the user to enter a height and then prints a reversed
 * triangle of the given height
 */

import java.util.Scanner;

public class Triangle {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter triangle height:");
        int height = sc.nextInt();

        for (int i = 1; i <= height; i++) {
            for (int j = height; j >= i; j--) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
