/**
 * Program that asks the user to enter valid numbers between 1 and 100
 * and then counts from these numbers to 1 in descending order
 */

import java.util.Scanner;

public class Counter {
    public static void main(String[] args) {
        int number;
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Enter the number to count from:");
            number = sc.nextInt();

            if (number >= 1 && number <= 100) {
                for (int i = number; i >= 1; i--) {
                    System.out.println(i);
                }
            }
        }
        while (number >= 1 && number <= 100);
    }
}
