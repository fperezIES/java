/**
 * Program that asks the user to enter numbers, until he types 0. Then,
 * the program must sum all the numbers entered by the user and show
 * the result and how many digits it has
 */

import java.util.Scanner;

public class SumDigits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter numbers. Enter 0 to finish:");
        int sum = 0;
        int number;
        do {
            number = sc.nextInt();
            sum += number;
        } while (number != 0);

        int digitCount = 0;
        /*
         * In order to determine how many digits the sum has, we can
         * divide by 10 iteratively, and then check how many times we 
         * have divided...
         * 
        int sumCopy = sum;
        
        while (sumCopy > 0)
        {
            digitCount++;
            sumCopy /= 10;
        }
        */

        /*
         * ... or we can convert the sum into a string and check its
         * length
         */

        digitCount = ("" + sum).length();
        //digitCount = String.valueOf(sum).length();


        System.out.println("The result is " + sum + " and it has " + digitCount + " digits");
    }
}
