/**
 * Another version of the "GramOunceConverter" exercise in which we
 * ask the user to enter the weight unit, and then, using a swith
 * structure, we determine if we must convert from grams to ounces
 * or vice versa
 */

import java.util.Scanner;

public class GramOunceConverter2 {
    static final float GRAMS_OUNCES = 28.3495f;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter weight:");
        float weight = sc.nextFloat();

        System.out.println("Enter unit (g or o):");
        String unit = sc.next();

        switch (unit) {
            case "g":
                float grams = weight / GRAMS_OUNCES;
                System.out.printf("%.2f ounces", grams);
                break;
            case "o":
                float ounces = weight * GRAMS_OUNCES;
                System.out.printf("%.2f grams", ounces);
                break;
            default:
                System.out.println("Unexpected unit");
        }
    }
}
