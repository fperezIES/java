/**
 * A version of "MarkCheck" exercise using arrays
 * (Arrays are not seen until Unit 3, but this exercise is a good
 * introduction to how to use them)
 */

import java.util.Scanner;

public class MarkCheckArrays {
    static final int N_MARKS = 3;

    public static void main(String[] args) {
        int marks[] = new int[N_MARKS];

        Scanner sc = new Scanner(System.in);

        System.out.printf("Enter %d marks:%n", marks.length);
        for (int i = 0; i < marks.length; i++) {
            marks[i] = sc.nextInt();
        }

        /* We use these two boolean values to determine if all the
         * elements of the array are greater or lower than 4,
         * respectively */

        boolean allGreaterOrEqual4 = true;
        boolean allLower4 = true;

        for (int i = 0; i < marks.length; i++) {
            if (marks[i] < 4) {
                allGreaterOrEqual4 = false;
            }else if (marks[i] >= 4) {
                allLower4 = false;
            }
        }

        if (allGreaterOrEqual4) {
            System.out.println("All marks are greater or equal than 4");
        } else if (allLower4) {
            System.out.println("No mark is greater or equal than 4");
        } else {
            System.out.println("Some marks are not greater or equal than 4");
        }

    }
}
