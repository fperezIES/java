/**
 * Program that checks the final value of some boolean and logic operators
 */

public class CheckBoolean {
    public static void main(String[] args) {
        int a = 3;
        int b = 5;
        int c = 8;

        boolean e1 = a < 2 && b >= 5 || c == 8;
        boolean e2 = a < 2 && (b >= 5 || c == 8);
        boolean e3 = !(a < 2) && (b >= 5 || c == 8);

        System.out.println(e1);
        System.out.println(e2);
        System.out.println(e3);
    }
}
