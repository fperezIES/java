/**
 * Program that asks the user to enter 3 marks, and then it
 * determines if all, none of some of them are greater or equal than 4
 */

import java.util.Scanner;

public class MarkCheck {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter 3 marks:");
        int mark1 = sc.nextInt();
        int mark2 = sc.nextInt();
        int mark3 = sc.nextInt();

        if (mark1 >= 4 && mark2 >= 4 && mark3 >= 4) {
            System.out.println("All marks are greater or equal than 4");
        } else if (mark1 < 4 && mark2 < 4 && mark3 < 4) {
            System.out.println("No mark is greater or equal than 4");
        } else {
            System.out.println("Some marks are not greater or equal than 4");
        }
    }
}
