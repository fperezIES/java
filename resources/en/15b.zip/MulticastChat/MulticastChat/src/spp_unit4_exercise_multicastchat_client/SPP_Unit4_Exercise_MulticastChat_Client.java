package spp_unit4_exercise_multicastchat_client;

import java.net.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * The client side of a chat application. It connects to the group with a 
 * specified nickname, and then the user will be able to send messages to the
 * group and see the whole conversation
 * @author nacho
 */
public class SPP_Unit4_Exercise_MulticastChat_Client extends Application 
{
    public static final int PORT = 6000;
    
    String nickName = "";
    TextArea txtConversation;
    TextField txtNick, txtMessage;
    Button btnConnect, btnSend;
    MulticastSocket ms;
    InetAddress group;
    ChatService service;
    
    @Override
    public void start(Stage primaryStage) 
    {        
        // Controls
        
        // Connection pane
        HBox connPane = new HBox(20);
        Label lblNick = new Label("Nickname: ");
        txtNick = new TextField();
        btnConnect = new Button("Connect");
        connPane.setAlignment(Pos.CENTER);
        connPane.getChildren().addAll(lblNick, txtNick, btnConnect);
        
        // Conversation
        txtConversation = new TextArea();
        
        // Send messages
        HBox messagePane = new HBox(20);
        txtMessage = new TextField();
        txtMessage.setMinWidth(300);
        btnSend = new Button("Send message");
        messagePane.setAlignment(Pos.CENTER);
        messagePane.getChildren().addAll(txtMessage, btnSend);
        
        // Events: connect to chat
        btnConnect.setOnAction(e ->
        {
            String nick = txtNick.getText().trim();
            if (nick.length() > 0)
                sendMessage(nick + " enters the chat", true);
            else
                showErrorMessage("Error connecting to server", "You must specify a valid nickname");
        });
        
        // Events: send message
        btnSend.setOnAction(e ->
        {
            if (txtMessage.getText().trim().length() > 0)
            {
                String msg = "[" + nickName + "]" + txtMessage.getText();
                sendMessage(msg, false);
            }
            else
                showErrorMessage("Error sending message", "Message is empty");
        });
        
        // Events: close window
        primaryStage.setOnCloseRequest(e ->
        {
            sendMessage(nickName + " leaves the chat", false);
            // Cancel the Service, leave group and close the socket
            service.cancel();
            try
            {
                ms.leaveGroup(group);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            try
            {
                ms.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        
        // Display panes
        BorderPane root = new BorderPane();
        root.setTop(connPane);
        root.setCenter(txtConversation);
        root.setBottom(messagePane);
        
        // Disable controls
        txtConversation.setDisable(true);
        txtMessage.setDisable(true);
        btnSend.setDisable(true);
        
        Scene scene = new Scene(root, 600, 500);
        
        primaryStage.setTitle("Multicast Chat");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) 
    {
        launch(args);
    }
    
    /**
     * Sends a message to the chat group
     * @param text Text to be sent
     * @param connect Sets whether it is our first (connection) message or not
     */
    public void sendMessage(String text, boolean connect)
    {
        try
        {
            // If it's our first message, connect to the group
            if (connect)
            {
                ms = new MulticastSocket(PORT);
                group = InetAddress.getByName("225.0.0.1");            
                ms.joinGroup(group);
                nickName = txtNick.getText();            
            }
            DatagramPacket packet = new DatagramPacket(text.getBytes(), text.length(), group, PORT);
            ms.send(packet);
            btnConnect.setDisable(true);
            txtNick.setDisable(true);
            txtConversation.setDisable(false);
            txtMessage.setDisable(false);
            btnSend.setDisable(false);

            // If it's our first message, start the service (after sending our
            // first connection message), and bind the text area to it
            if (connect)
            {
                service = new ChatService(ms, txtConversation);
                txtConversation.textProperty().bind(service.messageProperty());
                service.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
            showErrorMessage("Error connecting to server", "Unable to send message to server");
        }
    }
 
    public void showErrorMessage(String title, String msg)
    {
        Alert dialog = new Alert(Alert.AlertType.ERROR);
        dialog.setTitle("Error");
        dialog.setHeaderText(title);
        dialog.setContentText(msg);
        dialog.showAndWait();        
    }
    
}
