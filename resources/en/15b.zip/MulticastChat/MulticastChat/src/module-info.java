module MulticastChat {
    requires javafx.fxml;
    requires javafx.controls;

    opens spp_unit4_exercise_multicastchat_client;
}