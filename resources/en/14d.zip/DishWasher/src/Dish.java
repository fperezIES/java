
public class Dish 
{
    int number;
    
    public Dish(int number)
    {
        this.number = number;
    }
    
    public int getNumber()
    {
        return number;
    }
}
