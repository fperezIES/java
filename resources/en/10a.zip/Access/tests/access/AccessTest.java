package access;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AccessTest {

    @Test
    public void testValidUser()
    {
        Access access = new Access();

        assertTrue(access.validUser("pepito123", "sanvicente2019"));
        assertFalse(access.validUser("123pepito", "sanvicente2019"));
        assertFalse(access.validUser("pepe12", "sanvicente2019"));
        assertFalse(access.validUser("pepito12345", "sanvicente2019"));
        assertFalse(access.validUser("pepito123", "sanvi19"));
        assertFalse(access.validUser("pepito123", "123123123123"));
        assertFalse(access.validUser("pepito123", "aabbccddeeff"));
        assertFalse(access.validUser(null, "sanvicente2019"));
        assertFalse(access.validUser("pepito123", null));
    }

    @Test
    public void testRegister()
    {
        Access access = new Access();

        assertTrue(access.register("pepito123", "sanvicente2019"));
        // Check that we can't register an already existing user
        assertFalse(access.register("pepito123", "sanvicente2019"));

        access.register("user2", "pass2");
        access.register("user3", "pass3");
        access.register("user4", "pass4");
        access.register("user5", "pass5");
        access.register("user6", "pass6");
        access.register("user7", "pass7");
        access.register("user8", "pass8");
        access.register("user9", "pass9");
        access.register("user10", "pass10");
        // Map only allows up to 10 users
        assertFalse(access.register("user11", "pass11"));
    }
}