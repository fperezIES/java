import java.time.*;
import java.time.format.*;
import java.util.*;

/*
 * Program that asks the user the time zone and date of his/her birth, and
 * shows the same date/time in another time zone
 */ 
public class TimeZones
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        DateTimeFormatter formatter = 
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        LocalDateTime birthDate;
        String zone;
        
        System.out.println("Enter the zone of your birth:");
        zone = sc.nextLine();
        System.out.println("Enter your birth date (dd/mm/yyyy hh:mm:ss):");
        birthDate = LocalDateTime.parse(sc.nextLine(), formatter);
        
        ZonedDateTime zone1 = ZonedDateTime.of(birthDate, ZoneId.of(zone));
        ZonedDateTime zoneChicago = 
            zone1.withZoneSameInstant(ZoneId.of("America/Chicago"));
        ZonedDateTime zoneJapan =
            zone1.withZoneSameInstant(ZoneId.of("Asia/Tokyo"));
            
        
        System.out.println("Your birth date in Chicago: " + 
            formatter.format(zoneChicago));
        System.out.println("Your birth date in Japan: " + 
            formatter.format(zoneJapan));
    }
}
