import java.util.*;
import java.time.*;
import java.time.format.*;
import java.time.temporal.*;

/*
 * Program that asks the user his/her birth date and tells how old he/she is
 * and how many days are left until his/her next birthday
 */ 
public class NextBirthday
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate birthDate, now, nextBirthday;
        int age;
        
        System.out.println("Enter your birth date (dd/mm/yyyy):");
        birthDate = LocalDate.parse(sc.nextLine(), formatter);
        
        now = LocalDate.now();
        age = (int)(birthDate.until(now, ChronoUnit.YEARS));
        nextBirthday = birthDate.plus(age + 1, ChronoUnit.YEARS);
        
        System.out.println("You are " + age + " years old");
        System.out.println("Next birthday: " + 
            formatter.format(nextBirthday));
    }
}
