import java.time.*;
import java.time.format.*;
import java.util.*;

/*
 * Program that asks the user his/her birth date and tells the season of the
 * year associated to this birth date.
 */ 
public class BirthdaySeason
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        LocalDate birthDate;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-M-y");
        int day, month;
        
        System.out.println("Enter your birth date (d-m-y):");
        birthDate = LocalDate.parse(sc.nextLine(), formatter);
        month = birthDate.getMonthValue();
        day = birthDate.getDayOfMonth();
        
        if (month == 1 || month == 2 || (month == 12 && day >= 21) ||
            (month == 3 && day < 21))
        {
            System.out.println("It was winter");
        }
        else if (month == 4 || month == 5 || (month == 3 && day >= 21) ||
            (month == 6 && day < 21))
        {
            System.out.println("It was spring");
        }
        else if (month == 7 || month == 8 || (month == 6 && day >= 21) ||
            (month == 9 && day < 21))
        {
            System.out.println("It was summer");
        }
        else
        {
            System.out.println("It was autumn");
        }

    }
}
