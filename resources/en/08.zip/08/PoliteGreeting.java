import java.time.*;

/*
 * Program that gets current time and shows "Good morning", "Good afternoon",
 * "Good evening" or "Good night".
 */ 
public class PoliteGreeting
{
    public static void main(String[] args)
    {
        LocalTime now = LocalTime.now();
        
        if (now.getHour() >= 7 && now.getHour() < 12)
        {
            System.out.println("Good morning");
        }
        else if (now.getHour() >= 12 && now.getHour() < 18)
        {
            System.out.println("Good afternoon");
        }
        else if (now.getHour() >= 18 && now.getHour() < 21)
        {
            System.out.println("Good evening");
        }
        else
        {
            System.out.println("Good night");
        }
    }
}
