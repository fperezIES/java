import java.util.*;

/*
 * Program that asks the user his/her birth date and tells if it has taken
 * place this year or not
 */ 
public class UserBirthday
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int day, month, year;
        
        System.out.println("Enter your day of birth:");
        day = sc.nextInt();
        System.out.println("Enter your month of birth:");
        month = sc.nextInt();
        System.out.println("Enter your year of birth:");
        year = sc.nextInt();
        
        Calendar birthDate = Calendar.getInstance();
        birthDate.set(year, month-1, day);
        
        Calendar thisYear = Calendar.getInstance();
        thisYear.set(thisYear.get(Calendar.YEAR), month-1, day);
        
        if (thisYear.before(Calendar.getInstance()))
        {
            System.out.println("Your birthday has already taken place");
        }
        else
        {
            System.out.println("Your birthday has not taken place yet");
        }
    }
}
